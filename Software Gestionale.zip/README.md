WEB APP GESTIONALE

  CRM per la gestione di utenti, clienti e relative fatture.

FUNZIONALITÀ:


  I) Crea utenti di tipo "admin" i quali potranno eseguire tutte le operazioni o "user" i quali potranno solo visualizzare;

  II) Effettuare login e signup;

  III) Visualizza lista utenti, clienti e fatture;

  IV) Aggiunta,Rimuove,Modifica clienti e relative conseguenze sulle informazioni e dati  associati;

  V) Aggiunta,Rimuove,Modifica fatture;


AVVIO DEL SOFTWARE (DA TERMINALE):


  I) npm i;

  II) npm i bootstrap;

  III) npm i bootstrap-icons;

  IV) AVVIO => ng s -o 


LINGUAGGI E TECNOLOGIE UTILIZZATE:

  HTML
  CSS
  JavaScript
  Bootstrap
  TypeScript
  Angular

  <heart>/********************** GRAZIE EPICODE **********************/</heart>
                                      :-)                              


