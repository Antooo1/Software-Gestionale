import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StatoFattura } from '../models/stato-fattura';
import { FattureService } from '../services/fatture.service';

@Component({
  template: `
    <div class="container mt-5 text-center p-5">
      <form [formGroup]="form" (ngSubmit)="onSubmit(form)">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title mb-3 p-3">Aggiungi Fattura</h5>
            <div class="form-row">
              <div class="form-group col-2">
                <label for="data" class="mb-2">Data</label>
                <input
                  type="date"
                  formControlName="data"
                  id="data"
                  class="form-control"
                />
              </div>
              <div class="form-group col-1 mt-2">
                <label for="numero">Numero</label>
                <input
                  type="text"
                  formControlName="numero"
                  id="numero"
                  class="form-control form-control"
                />
              </div>
              <div class="form-group col-2">
                <label for="anno" class="mb-2">Anno</label>
                <input
                  type="text"
                  formControlName="anno"
                  id="anno"
                  class="form-control"
                />
              </div>
              <div class="form-group col-2">
                <label for="importo" class="mb-2">Importo</label>
                <input
                  type="text"
                  formControlName="importo"
                  id="importo"
                  class="form-control"
                />
              </div>
              <div class="form-group col-3">
                <label for="stato" class="mb-2">Stato</label>
                <select
                  formControlName="stato"
                  class="form-select form-control"
                  aria-label="Default select example"
                >
                  <option value="" selected>
                    Seleziona lo stato della fattura
                  </option>
                  <option
                    *ngFor="let stato of statiFattura"
                    value="{{ stato.id }}"
                  >
                    {{ stato.nome }}
                  </option>
                </select>
              </div>
            </div>
            <button type="submit" class="btn btn-primary mt-5 mb-3">
              Aggiungi
            </button>
          </div>
        </div>
      </form>
    </div>
  `,
  styles: [
    `
      .form-row {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
      }
      h5 {
        font-size: 1.2em;
        margin-bottom: 2px;
        background-color: rgb(183, 178, 173);
        border: 1px solid grey;
        border-radius: 3px;
      }

      button:hover {
        box-shadow: 0px 0px 10px #000000 !important;
        border-radius: 5px !important;
      }
      .card-body {
        padding: 3px;
        margin: 2px;
        background-image: linear-gradient(to left, white, rgb(65, 136, 236));
      }
    `,
  ],
})
export class FatturaFormPage implements OnInit {
  idCliente!: number;
  statiFattura!: StatoFattura[];
  form!: FormGroup;

  constructor(
    private fattSrv: FattureService,
    private actRoute: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.actRoute.params.subscribe((params) => {
      const id = +params['id'];

      this.idCliente = id;
    });

    this.form = this.fb.group({
      data: this.fb.control(null, Validators.required),
      numero: this.fb.control(null, Validators.required),
      anno: this.fb.control(null, Validators.required),
      importo: this.fb.control(null, Validators.required),
      stato: this.fb.control(null, Validators.required),
    });

    this.fattSrv.getTipiStatoFattura().subscribe((res) => {
      this.statiFattura = res.content;
    });
  }

  onSubmit(form: FormGroup) {
    console.log(form);

    try {
      this.fattSrv.fatturaForm(form.value, this.idCliente, 0);
    } catch (error: any) {
      console.error(error);
    } finally {
      this.router.navigate([`/clienti/${this.idCliente}/fatture`]);
    }
  }
}
