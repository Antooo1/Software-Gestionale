import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-navbar',
  template: `
    <nav class="navbar navbar-expand navbar-dark bg-primary">
      <div class="container-fluid">
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarTogglerDemo01"
          aria-controls="navbarTogglerDemo01"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page"
                >EpiCode Invoice Management Software
              </a>
            </li>
            <li *ngIf="!isLoggedIn" class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/login']"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: true }"
                >Login</a
              >
            </li>
            <li *ngIf="!isLoggedIn" class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/signup']"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: true }"
                >Signup</a
              >
            </li>
            <li *ngIf="isLoggedIn" class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/utenti']"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: true }"
                >Utenti</a
              >
            </li>
            <li *ngIf="isLoggedIn" class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/clienti']"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: true }"
                >Clienti</a
              >
            </li>
            <li *ngIf="isLoggedIn" class="nav-item">
              <a
                class="nav-link"
                [routerLink]="['/fatture']"
                routerLinkActive="active"
                [routerLinkActiveOptions]="{ exact: true }"
                >Fatture</a
              >
            </li>
          </ul>
          <div *ngIf="isLoggedIn" class="ms-auto">
            <p class="d-inline username-welc-back">
              Bentornato
              <span class="fst-italic fw-bolder">{{ currentUser }}</span>
            </p>
            <button class="btn btn-danger mx-3" (click)="onLogout()">
              Logout
            </button>
          </div>
        </div>
      </div>
    </nav>
  `,
  styles: [
    `
      nav,
      container-fluid {
        opacity: 0.65;
        transition-property: opacity;
        transition-duration: 1s;
        transition-timing-function: linear;
      }
      nav:hover {
        opacity: 1;
        transition-delay: 0.1s;
      }
      li:first-child {
        font-style: italic;
      }
      a:hover {
        box-shadow: 0px 0px 10px #000000;
        border-radius: 5px;
      }
    `,
  ],
})
export class NavbarComponent implements OnInit {
  isLoggedIn: boolean = false;

  constructor(private authSrv: AuthService) {}

  ngOnInit(): void {
    this.authSrv.isLoggedIn$.subscribe((isLoggedIn) => {
      this.isLoggedIn = isLoggedIn;
    });
  }

  onLogout() {
    this.authSrv.logout();
  }

  get currentUser() {
    const userJson = localStorage.getItem('user');
    if (!userJson) {
      return;
    }
    const user = JSON.parse(userJson);
    return user.username;
  }
}
