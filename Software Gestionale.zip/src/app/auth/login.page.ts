import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  template: `
    <div class="Header">
      <svg
        class="Header__svg"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 1337.97 684.43"
      >
        <path
          class="Header__shape bigSquare"
          fill="#16d5d1"
          d="M546.519 349.271l86.383-56.098 56.097 86.383-86.383 56.098z"
        />
        <path
          class="Header__shape triangle"
          fill="none"
          stroke="#ff4676"
          stroke-width="8"
          d="M372.15 462.17L321 434.58l-4.88 56.16z"
        />
        <circle
          class="Header__shape bigCircle"
          fill="#ff4676"
          cx="1076.52"
          cy="262.17"
          r="59"
        />
        <path
          class="Header__shape littleSquare"
          fill="#ffe430"
          d="M285.523 262.61l12.372-53.59 53.59 12.372-12.372 53.59z"
        />
        <circle
          class="Header__shape hoop"
          fill="none"
          stroke="#ffe430"
          stroke-width="13"
          cx="905.52"
          cy="447.17"
          r="45"
        />
        <circle
          class="Header__shape littleCircle"
          fill="#0f1c70"
          cx="1036.52"
          cy="203.17"
          r="27"
        />
      </svg>
      <h4 class="Header__title">Clienti e Fatture</h4>
    </div>

    <div class="container text-center">
      <div class="row">
        <div class="col">
          <div *ngIf="errorMessage" class="alert alert-danger" role="alert">
            {{ errorMessage }}
          </div>
          <form [formGroup]="form" (ngSubmit)="onSubmit(form)">
            <div class="form-group mb-4">
              <label for="username" class="mb-2">Username</label>
              <input
                type="text"
                formControlName="username"
                id="username"
                class="form-control"
              />
              <span
                *ngIf="
                  !form.controls['username'].valid &&
                  form.controls['username']?.touched
                "
                class="text-danger"
              >
                <ng-container *ngIf="getErrorController('username', 'required')"
                  >Devi inserire un username!</ng-container
                >
              </span>
            </div>
            <div class="form-group mb-4">
              <label for="password" class="mb-2">Password</label>
              <input
                type="password"
                formControlName="password"
                id="password"
                class="form-control"
              />
              <span
                *ngIf="
                  !form.controls['password'].valid &&
                  form.controls['password']?.touched
                "
                class="text-danger"
              >
                <ng-container
                  *ngIf="getErrorController('password', 'required')"
                  class="text-danger"
                  >Devi inserire una password!</ng-container
                >
              </span>
            </div>
            <button type="submit" class="btn btn-primary">
              <div
                *ngIf="isLoading; else elseText"
                class="spinner-border text-light"
                role="status"
              >
                <span class="visually-hidden">Loading...</span>
              </div>
              <ng-template #elseText>Accedi</ng-template>
            </button>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [],
  styleUrls: [`login.page.css`],
})
export class LoginPage implements OnInit {
  form!: FormGroup;
  errorMessage = undefined;
  isLoading: boolean = false;

  constructor(
    private authSrv: AuthService,
    private router: Router,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      username: this.fb.control(null, Validators.required),
      password: this.fb.control(null, Validators.required),
    });
  }

  async onSubmit(form: FormGroup) {
    this.isLoading = true;
    try {
      await this.authSrv.login(form.value).toPromise();
      form.reset();
      this.errorMessage = undefined;
      this.router.navigate(['/utenti']);
    } catch (error: any) {
      this.isLoading = false;
      this.errorMessage = error;
      console.error(error);
    }
  }

  getErrorController(name: string, error: string) {
    return this.form.get(name)?.errors![error];
  }
}
